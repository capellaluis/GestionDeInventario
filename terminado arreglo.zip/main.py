#Importar Funciones
from funciones_vista import *
from funciones_database import *
import sys

# Función principal para gestionar el flujo del programa
def iniciar_programa():
    while True:
        mostrar_menu()
        opcion = input("Seleccione una opción: ")
        procesar_opcion_menu(opcion)


def procesar_opcion_menu(opcion):
    if opcion == '1':
        opcion_procesar_producto()
    elif opcion == '2':
        opcion_visualizar_produtos()
    elif opcion == '3':
        opcion_actualizar_producto()
    elif opcion == '4':
        opcion_eleminar_producto()
    elif opcion == '5':
        opcion_Buscar_producto()
    elif opcion == '6':
        opcion_reporte_bajo_stock()
    elif opcion == '7':
        print("Saliendo del programa...")
        sys.exit()        
    else:
        print("Opción no válida. Por favor, seleccione una opción del 1 al 7.")

# Función para registrar un nuevo producto
def opcion_procesar_producto():

    nombre = leerString("Ingrese el nombre del producto: ")
    descripcion = leerString("Ingrese una descripción del producto: ")
    cantidad = leerInt("Ingrese la cantidad en stock: ")
    precio = leerFloat("Ingrese el precio del producto: ")
    categoria = leerString("Ingrese la categoría del producto: ")

    resultado = registrar_producto(nombre, descripcion, cantidad, precio, categoria)

    if resultado:
        mostrar_mensaje_subrayado("\nProducto guardado con exito")
    else:
        mostrar_mensaje_subrayado("\nSe produjo un error al guardar el producto")


def opcion_visualizar_produtos():
    
    inventario = obtener_todos_productos()

    if inventario:
        print("\n--- Lista de Productos ---")
        for indice, producto in enumerate(inventario, 1):
            imprimir_producto(indice, producto)
    else:
        mostrar_mensaje_subrayado("No hay productos en el inventario.")

# Función para actualizar producto
def opcion_actualizar_producto():
    opcion_visualizar_produtos()

    indice = int(input("\nSeleccione el número del producto que desea actualizar: ")) - 1
    if 0 <= indice < len(inventario):
        nueva_cantidad = int(input(f"Ingrese la nueva cantidad para '{inventario[indice]['nombre']}': "))
        nuevo_precio = float(input(f"Ingrese el nuevo precio para '{inventario[indice]['nombre']}': "))
        inventario[indice]['cantidad'] = nueva_cantidad
        inventario[indice]['precio'] = nuevo_precio
        mostrar_mensaje_subrayado("Producto actualizado con éxito.")
        
    else:
        print("Producto no válido.")

# Función para eliminar un producto
def opcion_eleminar_producto():
    opcion_visualizar_produtos()
    indice = int(input("Seleccione el número del producto que desea eliminar: ")) - 1
    if 0 <= indice < len(inventario):
        eliminado = inventario.pop(indice)
        mostrar_mensaje_subrayado(f"Producto '{eliminado['nombre']}' eliminado con éxito.")
    else:
        print("Producto no válido.")

# Función para buscar un producto
def opcion_Buscar_producto():
    nombre_buscar = input("Ingrese el nombre del producto que desea buscar: ").strip().lower()
    encontrado = False
    for producto in inventario:
        if producto['nombre'].lower() == nombre_buscar:
            print("\n--- Producto Encontrado ---")
            print(f"Nombre: {producto['nombre']}")
            print(f"Descripción: {producto['descripcion']}")
            print(f"Cantidad: {producto['cantidad']}")
            print(f"Precio: ${producto['precio']:.2f}")
            print(f"Categoría: {producto['categoria']}")
            encontrado = True
            break
    if not encontrado:
        print("Producto no encontrado en el inventario.")

# Función para generar reporte de productos con bajo stock
def opcion_reporte_bajo_stock():
    minimo_stock = int(input("Ingrese el mínimo de stock para el reporte: "))
    productos_bajo_stock = [p for p in inventario if p['cantidad'] < minimo_stock]
    if productos_bajo_stock:
        mostrar_mensaje_subrayado("Reporte de Productos con Bajo Stock")
        for producto in productos_bajo_stock:
            print(f"{producto['nombre']} - Cantidad: {producto['cantidad']}")
    else:
        print("No hay productos con bajo stock.")







# ******************************************************************
# INVOCAMOS A LA FUNCION PRINCIPAL
# ******************************************************************

# Iniciar el programa
iniciar_programa()

