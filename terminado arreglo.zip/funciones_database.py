# Inventario inicial como lista de diccionarios
inventario = [
    {"nombre": "Leche", "descripcion": "Leche descremada en caja", "cantidad": 10, "precio": 1800, "categoria": "Lácteos"},
    {"nombre": "Pan", "descripcion": "Pan integral fresco", "cantidad": 20, "precio": 400, "categoria": "Panadería"},
    {"nombre": "Arroz", "descripcion": "Arroz blanco de grano largo", "cantidad": 15, "precio": 1100, "categoria": "Cereales"},
    {"nombre": "Azúcar", "descripcion": "Azúcar refinada blanca", "cantidad": 8, "precio": 1030, "categoria": "Endulzantes"},
    {"nombre": "Café", "descripcion": "Café molido premium", "cantidad": 5, "precio": 8500, "categoria": "Bebidas"}
]


def registrar_producto(nombre, descripcion, cantidad, precio, categoria):
  
  producto = {
    "nombre": nombre,
    "descripcion": descripcion,
    "cantidad": cantidad,
    "precio": precio,
    "categoria": categoria
  }

  inventario.append(producto)
  return True

def obtener_todos_productos():
  return inventario
