# Acá se colocarán las funciones para mostrar o pedir datos

def mostrar_menu():
    
    print("\n--- Menú de Gestión de Productos ---")
    print("1. Agregar producto")
    print("2. Mostrar productos")
    print("3. Actualizar cantidad de producto")
    print("4. Eliminar producto")
    print("5. Buscar producto")
    print("6. Reporte de productos con bajo stock")
    print("7. Salir\n")

def leerString(mensaje):
    return input(mensaje)

def leerInt(mensaje):
    while True:
        try:
            return int(input(mensaje))
        except ValueError:
            print("Error: Por favor, ingresa un número entero válido.")

def leerFloat(mensaje):
    while True:
        try:
            return float(input(mensaje))
        except ValueError:
            print("Error: Por favor, ingresa un número decimal válido.")


def mostrar_mensaje_subrayado(mensaje):
    print("*" * 50)
    print(mensaje)
    print("*" * 50)

def imprimir_producto(indice, producto):
  print(f"{indice}. {producto['nombre']} - {producto['descripcion']} - "
        f"Cantidad: {producto['cantidad']} - Precio: ${producto['precio']:.2f} - "
        f"Categoría: {producto['categoria']}")