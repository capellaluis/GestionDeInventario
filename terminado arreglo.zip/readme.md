### main
Contiene la lógica a llevar entre la vista y el modulo de base de datos

### Base de datos:
contiene el array o la conex a sqlite

## vista:
solo muestra o pide datos
